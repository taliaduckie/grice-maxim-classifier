import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

if not os.environ.get("ANTHROPIC_API_KEY"):
    print("ANTHROPIC_API_KEY not set")
    sys.exit(1)

import anthropic
import pandas as pd
from predict import predict

EXCHANGE_NORMS = {
    "performance_eval": (
        "Cooperative responses give concrete, specific assessment — actual examples, "
        "actual numbers. Vague praise or criticism doesn't count."
    ),
    "technical": (
        "You're expected to identify root cause, list what you tried, or ask a "
        "clarifying question. 'It should work' without evidence is suspect."
    ),
    "status_update": (
        "What's done, what's blocked, what's next. 'Making progress' alone is "
        "underinformative."
    ),
    "personal": (
        "Lower bar — acknowledging the question and sharing as much as you're "
        "comfortable with is fine. Deflection here might be opting out, not violating."
    ),
    "decision": (
        "Take a position or lay out the tradeoffs. 'Either way works' could be "
        "genuine flexibility or avoidance."
    ),
    "knowledge": (
        "Accurate, clear, appropriately detailed. Hand-waving is a Manner violation; "
        "being wrong is Quality."
    ),
    "conflict": (
        "Address the disagreement directly. Saying 'that's not how I remember it' "
        "without giving your version is underinformative."
    ),
    "instruction": (
        "Clear ordered steps. 'It's pretty straightforward' with no actual steps "
        "is a Manner violation."
    ),
}

client = anthropic.Anthropic()


def classify_with_claude(utterance: str, context: str, exchange_type: str) -> dict:
    norm = EXCHANGE_NORMS.get(exchange_type, "No specific norm defined.")

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=500,
        system=(
            "You are evaluating whether the following utterance violates "
            f"a Gricean maxim. The exchange type is {exchange_type}. "
            f"The clarity norm for this exchange type is: {norm} "
            "Classify: Cooperative / Quantity / Quality / Relation / Manner. "
            "Explain your reasoning in 2-3 sentences. "
            "Then state whether your reasoning relied on any surface-level "
            "linguistic markers (caps, scare quotes, hedging language, etc.) "
            "Answer the surface proxy question with just 'yes' or 'no'."
        ),
        messages=[{
            "role": "user",
            "content": (
                f"Context: {context}\n"
                f"Utterance: {utterance}\n\n"
                "Classification:"
            ),
        }],
    )

    text = response.content[0].text

    # grab the label from the first line
    lines = text.strip().split("\n")
    label = "unknown"
    for candidate in ["Cooperative", "Quantity", "Quality", "Relation", "Manner"]:
        if candidate.lower() in lines[0].lower():
            label = candidate
            break

    return {
        "claude_label": label,
        "claude_reasoning": text,
    }


def compare(csv_path: str, output_path: str = None):
    df = pd.read_csv(csv_path)
    results = []
    n = len(df)

    print(f"Running {n} pairs through RoBERTa + Claude...\n")

    for i, row in df.iterrows():
        utterance = str(row["utterance"])
        context = str(row["context"])
        exchange_type = str(row.get("exchange_type", "unknown"))

        roberta_pred = predict(utterance, context)
        claude_pred = classify_with_claude(utterance, context, exchange_type)

        agree = roberta_pred["predicted_maxim"] == claude_pred["claude_label"]

        result = {
            "utterance": utterance,
            "context": context,
            "exchange_type": exchange_type,
            "gold_maxim": row.get("maxim", ""),
            "roberta_label": roberta_pred["predicted_maxim"],
            "roberta_confidence": f"{roberta_pred['confidence']:.3f}",
            "claude_label": claude_pred["claude_label"],
            "agree": agree,
            "claude_reasoning": claude_pred["claude_reasoning"],
        }
        results.append(result)

        status = "✓ agree" if agree else "✗ DISAGREE"
        print(
            f"  [{i+1}/{n}] {utterance[:40]:<40} "
            f"R={roberta_pred['predicted_maxim']:<12} "
            f"C={claude_pred['claude_label']:<12} "
            f"{status}"
        )

        time.sleep(0.5)

    agreements = sum(1 for r in results if r["agree"])
    print(f"\nAgreement: {agreements}/{n} ({agreements/n:.1%})")

    disagreements = [r for r in results if not r["agree"]]
    if disagreements:
        print(f"\nDisagreements ({len(disagreements)}):")
        for r in disagreements:
            print(
                f"  {r['utterance'][:40]:<40} "
                f"R={r['roberta_label']:<12} C={r['claude_label']:<12} "
                f"gold={r['gold_maxim']}"
            )

    if output_path:
        with open(output_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=results[0].keys())
            writer.writeheader()
            writer.writerows(results)
        print(f"\nResults written to {output_path}")

    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Compare RoBERTa and Claude classifiers on adversarial examples.",
    )
    parser.add_argument(
        "--data",
        default=str(Path(__file__).parent.parent / "data" / "annotated" / "ambiguous_exchanges.csv"),
        help="Path to adversarial CSV.",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Path to write comparison results CSV.",
    )
    args = parser.parse_args()
    compare(args.data, args.output)
