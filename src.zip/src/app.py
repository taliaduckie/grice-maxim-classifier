import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import gradio as gr
from predict import predict

FEEDBACK_PATH = Path(__file__).parent.parent / "data" / "feedback" / "corrections.csv"

# examples that show off each maxim. picked these because they're
# fun and also because "The weather is nice today" is basically
# the project's mascot at this point.
EXAMPLES = [
    ["The weather is nice today.", "Why were you late to the meeting?"],
    ["Oh sure, I LOVE waiting in line for three hours.", "How do you feel about the DMV?"],
    ["The meeting is at 3pm in room 204.", "When and where is the meeting?"],
    ["I may or may not have potentially been in a situation where something could have occurred.", "What happened?"],
    ["Some students passed.", "Did everyone pass the exam?"],
    ["React is a programming language.", "What framework are you using?"],
    ["Great, the client loved it. You could really tell from how fast they left.", "How did the presentation land?"],
]

INFO_TEXT = """
### the maxims (very briefly)

Grice (1975) said cooperative speakers follow four maxims:

- **Quantity** — say enough but not too much
- **Quality** — don't say what you believe to be false
- **Relation** — be relevant
- **Manner** — be clear

The fifth label, **Cooperative**, just means none of the above were violated.

### flouting vs violating

Flouting = breaking a maxim on purpose so the listener picks up on it (sarcasm, irony, indirect refusal).
Violating = breaking it by accident or to deceive.

The model can't reliably tell flouting from violating yet — it predicts the maxim only.

### why the model might disagree with you

Pragmatics is subjective. "Fine." could be Quantity (too little) or Manner (vague) depending on what
you think the underlying problem is. Even linguists disagree ~20-30% of the time. If confidence is
below 70%, take it as a starting point not a verdict.
"""


def classify(utterance: str, context: str) -> tuple:
    if not utterance.strip():
        return {"label": "Enter an utterance", "confidences": {}}, ""

    result = predict(utterance, context)
    confidence = result["confidence"]

    # confidence warning
    if confidence < 0.5:
        warning = (
            f"Low confidence ({confidence:.0%}). The model is unsure about this one — "
            f"the prediction may not be reliable. Consider the runner-up labels."
        )
    elif confidence < 0.7:
        warning = (
            f"Moderate confidence ({confidence:.0%}). The model leans toward "
            f"{result['predicted_maxim']} but isn't highly certain."
        )
    else:
        warning = ""

    label_output = {
        "label": f"{result['predicted_maxim']} ({result['violation_type']})",
        "confidences": {
            maxim: score for maxim, score in result["all_scores"].items()
        },
    }

    return label_output, warning


def submit_correction(utterance: str, context: str, correct_maxim: str, notes: str) -> str:
    if not utterance.strip() or not correct_maxim.strip():
        return "Please enter an utterance and select a maxim."

    # ensure feedback directory exists
    FEEDBACK_PATH.parent.mkdir(parents=True, exist_ok=True)

    file_exists = FEEDBACK_PATH.exists()
    with open(FEEDBACK_PATH, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["utterance", "context", "corrected_maxim", "notes"])
        if not file_exists:
            writer.writeheader()
        writer.writerow({
            "utterance": utterance,
            "context": context,
            "corrected_maxim": correct_maxim,
            "notes": notes,
        })

    return f"Correction saved. Thank you!"


# build the interface with tabs
with gr.Blocks(title="Grice Maxim Classifier") as demo:
    gr.Markdown("# Grice Maxim Classifier")
    gr.Markdown(
        "Classify an utterance by which Gricean maxim it violates (if any). "
        "Paste what someone said and what they were responding to."
    )

    with gr.Tabs():
        with gr.Tab("Classify"):
            with gr.Row():
                with gr.Column():
                    utterance_input = gr.Textbox(
                        label="Utterance",
                        placeholder="The weather is nice today.",
                        lines=2,
                    )
                    context_input = gr.Textbox(
                        label="Context (what they were responding to)",
                        placeholder="Why were you late to the meeting?",
                        lines=2,
                    )
                    classify_btn = gr.Button("Classify", variant="primary")

                with gr.Column():
                    label_output = gr.Label(label="Prediction", num_top_classes=5)
                    warning_output = gr.Textbox(
                        label="Confidence note",
                        interactive=False,
                        lines=2,
                    )

            classify_btn.click(
                fn=classify,
                inputs=[utterance_input, context_input],
                outputs=[label_output, warning_output],
            )

            gr.Examples(
                examples=EXAMPLES,
                inputs=[utterance_input, context_input],
            )

        with gr.Tab("Correct a prediction"):
            gr.Markdown(
                "Think the model got it wrong? Submit a correction. "
                "These get saved for review and may improve future versions."
            )
            corr_utterance = gr.Textbox(label="Utterance", lines=2)
            corr_context = gr.Textbox(label="Context", lines=2)
            corr_maxim = gr.Dropdown(
                choices=["Cooperative", "Quantity", "Quality", "Relation", "Manner"],
                label="Correct maxim",
            )
            corr_notes = gr.Textbox(
                label="Notes (optional)",
                placeholder="Why you think this is the right label...",
                lines=2,
            )
            corr_btn = gr.Button("Submit correction")
            corr_result = gr.Textbox(label="Status", interactive=False)

            corr_btn.click(
                fn=submit_correction,
                inputs=[corr_utterance, corr_context, corr_maxim, corr_notes],
                outputs=corr_result,
            )

        with gr.Tab("About"):
            gr.Markdown(INFO_TEXT)

if __name__ == "__main__":
    demo.launch()
